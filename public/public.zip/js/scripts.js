
$(document).ready(function(){
    var page = $('#page').val();
    if(page == "items") {
        $('#addItemForm').hide();
    } else if (page == "users") {
        $('#addItemForm').hide();
    } else if(page == "salesAdd") {
        $('#showItemsByID').hide();
        $('#btnCheckout').hide();
        var cashReceived = $('#cashReceived');
        $('#findProductByID').on('keyup', function(e) {
            if (e.keyCode === 13) {
;               addItemToCart($(this).val());
            } else {
                showItemsByID($(this).val());
            }
        });
        $('#findProductByID').on('dblclick', function(e) {
            $.ajax({
                type: "GET",
                url: "/search/all",
                cache: false,
                success: function(html)
                {
                    $("#showItemsByID").html(html).slideDown(200);
                }
            });
        });
        $('#btnCheckout').on('click', function(e) {
            if(parseFloat(cashReceived.val()) >= parseFloat($('span#pTotal').text())) {
                if (confirm('Are you sure you want to checkout this transaction?')) {

                } else
                    e.preventDefault();
            } else {
                alert('Insufficient cash.');
            }
        });
        $(function(){
            //acknowledgement message
            $("td[contenteditable=true]").blur(function(){
                var field_userid = $(this).attr("id") ;
                var value = $(this).text() ;
                $.post('/cart/edit/'+field_userid , field_userid + "=" + value, function(data){
                    location.reload();
                });
            });
        });
        cashReceived.on('keyup', function() {
            var cashVal = $('#cashReceived').val();
            var pTotal = $('span#pTotal').text();

            $('#pChange').val(compute(parseFloat(pTotal), parseFloat(cashVal), '-'));
            if(parseFloat(cashVal) >= parseFloat(pTotal)) {
                $('#btnCheckout').show();
            } else {
                $('#btnCheckout').hide();
                $('#pChange').val('0.00');
            }

        });
    } else if(page == "checkout") {
        window.print();
    } else if(page == "branch") {
        $('#addItemForm').hide();
    }



/* swap open/close side menu icons */
$('[data-toggle=collapse]').click(function(){
  	// toggle icon
  	$(this).find("i").toggleClass("glyphicon-chevron-right glyphicon-chevron-down");
});
});

function btnAddItem() {
    $("#addItemForm").fadeIn(500);
}

function btnCloseAddItem() {
    $("#addItemForm").fadeOut(200);
}

function showItemsByID(id) {
    id = id.trim();
    if(id.length > 0) {
        //$('#showItemsByID').slideDown(200);
        var dataString = 'itemID='+ id;
        if(id!='')
        {
            $.ajax({
                type: "POST",
                url: "/search",
                data: dataString,
                cache: false,
                success: function(html)
                {
                    $("#showItemsByID").html(html).slideDown(200);
                }
            });
        }return false;
    } else
        $('#showItemsByID').slideUp(200);

}

function addItemToCart(id) {
    //alert(id);
    id = id.trim();
    if(id.length > 0) {
        //$('#showItemsByID').slideDown(200);
        //var dataString = 'id=' + id;
        if (id != '') {
            $.ajax({
                type: "GET",
                url: "/cart/add/" + id,
                //data: dataString,
                cache: false,
                success: function (html) {
                    location.reload();
                },
                error: function() {
                    alert('Item ID not found.');
                }
            });
        }
        return false;
    }
}

function compute(amt, cash, op) {
    switch (op) {
        case "-":
            return parseFloat(cash - amt);
            //alert(cash);
    }

}